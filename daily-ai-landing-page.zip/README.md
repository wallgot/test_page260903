# Daily AI Landing Page

AI 뉴스레터 랜딩페이지 샘플입니다.

## 실행 방법

1. 이 프로젝트 폴더를 다운로드합니다.
2. VS Code에서 폴더를 엽니다.
3. Live Server 확장을 설치합니다.
4. `index.html` 우클릭 후 `Open with Live Server`를 선택합니다.

## 폴더 구조

- `index.html` — 페이지 구조
- `styles.css` — 전체 스타일
- `script.js` — FAQ 열고 닫기, 연도 표시

## 브라우저에서 직접 열기

브라우저에서 `index.html`을 열어도 동작합니다.

## 참고

- 다크 프리미엄 UI
- 비전문가 대상 AI 뉴스레터 메시지
- 매일 3분 읽기형 콘텐츠 구조
- 무료 + 광고 기반 수익 모델
